import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';


import '../../Component/Home/CardLectureComnent.dart';
import '../../View_Model/Block/Final/Final_Cubit.dart';
import '../../View_Model/Block/Final/Final_States.dart';
import 'HomeScreen.dart';
import 'nev_barLayout.dart';

class Final extends StatelessWidget{
  const Final({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(create: (context) => FinalCubit()..getFinalData(),
      child:  BlocConsumer<FinalCubit,FinalStates>(
        listener: (context, state) {

        },
        builder: (context, state) {
          FinalCubit finalCubit = FinalCubit.get(context);
          return Scaffold(
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.white,
              leading:   InkWell(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (context)=>NevBarLayout())),
                  child: const Icon(Icons.arrow_back_ios,size: 24,color: Colors.deepOrangeAccent,)),
              title: Text("Final",
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                  )),
              actions: [
                PopupMenuButton(
                    icon: const Icon(Icons.filter_alt, color: Colors.deepOrange,),
                    itemBuilder:(context) => [
                      PopupMenuItem(
                        value: 1,
                        child: Text("All Sections", style: GoogleFonts.poppins(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                        )),
                      ),
                      PopupMenuItem(
                        value: 2,
                        child: Text("Finished Sections", style: GoogleFonts.poppins(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          textStyle: const TextStyle(color: Colors.black, letterSpacing: .5),
                        )),
                      ),
                      PopupMenuItem(
                        value: 2,
                        child: Text("Remaining Sections", style: GoogleFonts.poppins(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          textStyle: TextStyle(color: Colors.black, letterSpacing: .5),
                        )),
                      )
                    ]
                ),
              ],
            ),
            body: Container
              (
                child: finalCubit.examModel ==null? const Center(child: CircularProgressIndicator(color: Colors.deepOrangeAccent),):
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: finalCubit.examModel!.data!.length,
                  itemBuilder: ((context, index) {
                    return finalCubit.examModel!.data![index].finals == true? lectureCard(finalCubit.examModel!.data![index].examSubject.toString(),
                        finalCubit.examModel!.data![index].examDate.toString(),
                        finalCubit.examModel!.data![index].examStartTime.toString(),
                        finalCubit.examModel!.data![index].examEndTime.toString()):SizedBox();
                  } ),
                )

            ),
          );
        },
      ),);
  }

}