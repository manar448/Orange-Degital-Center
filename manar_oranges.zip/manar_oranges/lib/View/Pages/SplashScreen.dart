import 'dart:async';

import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

import 'LoginScreen.dart';


class splash extends StatefulWidget {
  const splash({Key? key}): super(key: key);


  @override
  State<splash> createState() => SplashScreen();
}

class SplashScreen extends State<splash> {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Timer(
        Duration(seconds: 4),
            () =>
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => Login())));

    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(
                image: AssetImage("assets/images/logo.png")
                , width: 300),
            SizedBox(height: 5),
            Center(

              child:
              LinearPercentIndicator(
                width: 360,
                lineHeight: 7,
                percent: 1,
                linearStrokeCap: LinearStrokeCap.roundAll,
                progressColor: Colors.deepOrangeAccent,
                backgroundColor: Colors.blueGrey,
                animation: true,
                animationDuration: 3105,

              ),

            )

          ],
        ),
      ),

      /*theme: ThemeData(
        primarySwatch: Colors.orange,
      ),

      home: login()*/
    );
  }
}
