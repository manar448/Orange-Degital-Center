import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

import 'nev_barLayout.dart';


class Events extends StatelessWidget {
  const Events({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.white,
            leading: InkWell(
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const NevBarLayout())),
              child: const Icon(
                Icons.arrow_back_ios,
                color: Colors.deepOrange,
              ),
            ),
            centerTitle: true,
            title: Text(
              "Events",
              style: GoogleFonts.poppins(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                textStyle: const TextStyle(
                  color: Colors.black,
                ),
              ),
            )),
        body: SfCalendar(
            view: CalendarView.month,
            initialSelectedDate: DateTime.now(),
            monthViewSettings: const MonthViewSettings(
                appointmentDisplayMode:
                    MonthAppointmentDisplayMode.appointment)));
  }
}
