import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../Component/Common/elevatedButton.dart';
import '../../Component/Support/textformfiedComponent.dart';



class Support extends StatelessWidget {
  const Support({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(

      appBar: AppBar(
          leading: InkWell(
              onTap: () => Navigator.pop(context),
              child:
                  const Icon(Icons.arrow_back_ios, color: Colors.deepOrangeAccent)),
          centerTitle: true,
          backgroundColor: Colors.white,
          title: Text(
            "Support",
            style: GoogleFonts.poppins(
              fontSize: 25,
              fontWeight: FontWeight.w600,
              color: Colors.black,
            ),
          )),
      body: SingleChildScrollView(
        child:Column(children: [
        textFormFiledSupport("Name", const Icon(Icons.person,color: Colors.black38)),
        textFormFiledSupport("E-Mail", const Icon(Icons.email,color: Colors.black38)),
        Container(
          margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          width: 350,
          child: TextFormField(
            minLines: 6,
            maxLines: 8,
            keyboardType: TextInputType.multiline,
            decoration: InputDecoration(
              focusedBorder: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(5)),
                  borderSide: BorderSide(
                    color: Colors.deepOrangeAccent,
                  )),
              hintText: "What's makeing you unhappy?",
              fillColor: Colors.grey[200],
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
          ),
        ),
        elevatedButton(
          "Submit",
          () {},
        )
      ]),
      ));
  }
}
