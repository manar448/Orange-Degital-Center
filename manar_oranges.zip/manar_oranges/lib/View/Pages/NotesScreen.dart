import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'AddNotesScreen.dart';
import 'nev_barLayout.dart';


class Notes extends StatelessWidget {
  const Notes({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(
              height: 30,
            ),
            Row(
              children: [
                InkWell(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const NevBarLayout())),
                    child: const Icon(Icons.arrow_back_ios_new)),
                const SizedBox(
                  width: 120,
                ),
                Text(
                  "Notes",
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w500,
                      fontSize: 30,
                      color: Colors.black,
                      letterSpacing: .5),
                ),
              ],
            ),
            const SizedBox(
              height: 300,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("There's No Data To Show",
                    style: GoogleFonts.poppins(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                      textStyle:
                          const TextStyle(color: Colors.black, letterSpacing: .5),
                    ))
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blueGrey[200],
        foregroundColor: Colors.black,
        onPressed: () => {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => const AddNotes()))
        },
        child: const Icon(Icons.add, size: 25, color: Colors.black),
      ),
    );
  }
}
