import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget orangeLogo() {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(
        "Orange",
        style: GoogleFonts.poppins(
            fontSize: 25,
            fontWeight: FontWeight.w600,
            color: Colors.deepOrangeAccent),
      ),
      Text(
        " Digital Center",
        style: GoogleFonts.poppins(fontSize: 25, fontWeight: FontWeight.w600),
      ),
    ],
  );
}
