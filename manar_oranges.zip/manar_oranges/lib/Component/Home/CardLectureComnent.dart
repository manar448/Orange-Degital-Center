import 'package:flutter/material.dart';

Widget lectureCard(String label, String day, String stime, String etime) {
  return Container(
    height: 110,
    width: 350,
    margin: const EdgeInsets.all(10),
    child: Card(
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 13),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(width: 10),
              Text(label,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w500)),
              const SizedBox(width: 200),
              const Icon(Icons.timer, size: 20),
              const Text("2hrs", style: TextStyle(fontSize: 15))
            ],
          ),
          const SizedBox(height: 15),
          Row(
            children: [
              const SizedBox(width: 10),
              Column(
                children: [
                  Text("Lecture Day",
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: Colors.grey[600])),
                  const SizedBox(
                    height: 3,
                  ),
                  Row(
                    children: [
                      const SizedBox(width: 2),
                      Icon(Icons.calendar_month_rounded,
                          size: 18, color: Colors.grey[800]),
                      const SizedBox(width: 3),
                      Text(day,
                          style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              color: Colors.black))
                    ],
                  ),
                ],
              ),
              const SizedBox(width: 40),
              Column(
                children: [
                  Text("Start Time",
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: Colors.grey[600])),
                  const SizedBox(
                    height: 3,
                  ),
                  Row(
                    children: [
                      const SizedBox(width: 3),
                      const Icon(Icons.watch_later,
                          size: 20, color: Colors.greenAccent),
                      const SizedBox(width: 3),
                      Text(stime,
                          style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: Colors.black))
                    ],
                  ),
                ],
              ),
              const SizedBox(width: 40),
              Column(
                children: [
                  Text("Lecture Day",
                      style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[600])),
                  const SizedBox(
                    height: 3,
                  ),
                  Row(
                    children: [
                      const SizedBox(width: 3),
                      const Icon(Icons.watch_later,
                          size: 20, color: Colors.redAccent),
                      const SizedBox(width: 3),
                      Text(etime,
                          style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87))
                    ],
                  ),
                ],
              )
            ],
          )
        ],
      ),
    ),
  );
}
