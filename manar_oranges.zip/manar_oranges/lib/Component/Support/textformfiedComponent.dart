import 'package:flutter/material.dart';

Widget textFormFiledSupport(String txt, Icon icon) {
  return Container(
    margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
    width: 350,
    child: TextFormField(
      obscureText: true,
      decoration: InputDecoration(
        focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            borderSide: BorderSide(
              color: Colors.deepOrangeAccent,
            )),
        labelText: txt,
        hintText: txt,
        hintStyle: TextStyle(color: Colors.black38),
        labelStyle: TextStyle(color: Colors.black38) ,
        prefixIcon: icon,
        fillColor: Colors.grey[200],
        filled: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
        ),
      ),

    ),
  );
}
