import 'package:flutter/material.dart';

Widget textFormFiled(String txt, TextEditingController editingController) {
  return Container(
    margin: const EdgeInsets.fromLTRB(0, 10, 0, 10),
    width: 350,
    child: TextFormField(
      obscureText: false,
      controller: editingController,
      decoration: InputDecoration(
          labelText: txt,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(5)),
              borderSide: BorderSide(
                color: Colors.deepOrangeAccent,
              ))),
    ),
  );
}
