import 'package:flutter/material.dart';
import 'package:manar_oranges/View/Pages/NewsScreen.dart';
import 'View/Pages/LoginScreen.dart';
import 'View/Pages/SupportScreen.dart';
import 'View_Model/Database/network/dio_helper.dart';
import 'View/Pages/SplashScreen.dart';

void main() async {
  await DioHelper.init();
  runApp(Myapp());

}
class Myapp extends StatelessWidget {
  const Myapp({Key? key}): super(key: key);


  @override
  Widget build(BuildContext context) {
    return  const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: splash()
    );

  }
}

