part of 'layout_Cubit.dart';

@immutable
abstract class LayoutStates{}
class LayoutInitialState extends LayoutStates{}
class LayoutChange extends LayoutStates{}