import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../View/Pages/HomeScreen.dart';
import '../../../View/Pages/NewsScreen.dart';
import '../../../View/Pages/SettingScreen.dart';


part 'layout_State.dart';

class LayoutCubit extends Cubit<LayoutStates> {
  LayoutCubit() : super(LayoutInitialState());

  static LayoutCubit get(BuildContext context) => BlocProvider.of(context);
  List<Widget> list = [const HomePage(), const News(), const Setting()];
  int currentIndex = 0;

  void changeCurrent(int newIndex) {
    currentIndex = newIndex;
    emit(LayoutChange());
  }
}
