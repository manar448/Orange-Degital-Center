
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../Constent.dart';
import '../../../Model/ExamModel.dart';
import '../../Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';
import 'Final_States.dart';


class FinalCubit extends Cubit<FinalStates>
{
  FinalCubit() : super(FinaLInitial());
  static FinalCubit get(BuildContext context) =>BlocProvider.of(context);
  ExamModel? examModel;

  void getFinalData()
  {
    //var query ={"final": false};
    DioHelper.getData(url: examsEndPoint,token: token).then((value) {
      examModel = ExamModel.fromJson(value.data);
      print(examModel!.code);
      emit(FinaLStoredData());
    });
  }
}