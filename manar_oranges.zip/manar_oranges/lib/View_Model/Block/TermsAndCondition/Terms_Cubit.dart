import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../Constent.dart';
import '../../../Model/TermsAndConditionModel.dart';
import '../../Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';
import 'Terms_States.dart';


class TermsCubit extends Cubit<TermsStates>
{
  TermsCubit() : super(TermsIntialState());

  static TermsCubit get(BuildContext context)=> BlocProvider.of(context);
  TermModel? termModel;
  void getTerms()
  {
     DioHelper.getData(url: termsEndPoint,token: token).then((value) {
       termModel=TermModel.fromJson(value.data);
       print(value.statusCode);
       emit(TermsStoredData());
     });
  }

}