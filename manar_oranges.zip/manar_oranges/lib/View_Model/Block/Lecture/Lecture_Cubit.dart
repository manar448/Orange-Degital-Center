import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../Constent.dart';
import '../../../Model/LectureModel.dart';
import '../../Database/network/dio_helper.dart';
import '../../Database/network/end_points.dart';
import 'Lecture_States.dart';

class LectureCubit extends Cubit<LectureStates> {
  LectureCubit() : super(LectureInitial());

  static LectureCubit get(BuildContext context) => BlocProvider.of(context);
  LectureModel? lectureModel;

  void getLectureData() {
    DioHelper.getData(url: lectureEndPoint, token: token).then((value) {
      lectureModel = LectureModel.fromJson(value.data);
      print(lectureModel!.code);
      emit(LectureStoredData());
    });
  }
}
