
abstract class LectureStates{}

class LectureInitial extends LectureStates{}

class LectureStoredData extends LectureStates{}

