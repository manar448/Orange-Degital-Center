package com.example.manar_oranges

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
